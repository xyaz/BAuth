//
//  BiometridAuthFace.h
//  BiometridAuth
//
//  Created by Tiago Carvalho on 07/02/2018.
//  Copyright © 2018 Tiago Carvalho. All rights reserved.
//

#import "BiometridAuth.h"
#import "BiometridAuthFaceResponse.h"
#import <Foundation/Foundation.h>

@interface BiometridAuthFace : NSObject

+ (instancetype)sharedInstance;

/*!
 *  @discussion Face engine.
 *  @param sessionType Session type.
 *  @param userId Biometrid's user identifier (send nil to get userId from photo).
 *  @param filePath File path of the photo to be submitted (send nil to start liveness process).
 *  @param viewController View controller where the face liveness engine is going to be launched.
 */
- (void)faceEngine:(SessionType)sessionType user:(NSString*)userId withFilePath:(NSString*)filePath inViewController:(UIViewController*)viewController andCallback:(void(^)(NSDictionary *response, BiometridAuthFaceResponse *baFaceResponse, NSError *error))completion;

/*!
 *  @discussion Get face engine's liveness status in the BO.
 *  @param userId Biometrid's user identifier.
 */
- (void)getLivenessStatus:(NSString*)userId andCallback:(void(^)(NSDictionary *response, BOOL hasLiveness, NSError *error))completion;

@end
