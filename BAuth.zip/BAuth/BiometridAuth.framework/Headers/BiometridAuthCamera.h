//
//  BiometridAuthCamera.h
//  BiometridAuth
//
//  Created by Tiago Carvalho on 29/12/2017.
//  Copyright © 2017 Tiago Carvalho. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import <UIKit/UIKit.h>

@interface BiometridAuthCamera : NSObject

@property AVCaptureDevicePosition position;
@property UIView *view;

/*!
 *  @discussion Start camera.
 *  @param position AVCaptureDevicePosition of the camera (front/back).
 *  @param view UIView where camera is launched.
 */
+ (instancetype)startWithPosition:(AVCaptureDevicePosition)position inView:(UIView*)view;

/*!
 *  @discussion Take a photo.
 *  @param delegate AVCapturePhotoCaptureDelegate delegate.
 */
- (void)takePhotoWithDelegate:(id<AVCapturePhotoCaptureDelegate>)delegate;

/*!
 *  @discussion Stop camera.
 */
- (void)stop;

@end


