//
//  BiometridAuthEnums.h
//  BiometridAuth
//
//  Created by Tiago Carvalho on 29/12/2017.
//  Copyright © 2017 Tiago Carvalho. All rights reserved.
//

#ifndef BiometridAuthEnums_h
#define BiometridAuthEnums_h

/*!
 * @typedef EngineType
 * @brief The type of engine being used.
 * @constant FACE Referring to face engine.
 * @constant VOICE Referring to voice engine.
 * @constant DOCUMENT Referring to document engine.
 */
typedef NS_ENUM(NSInteger, EngineType) {
    
    FACE = 1,
    VOICE,
    DOCUMENT
};

/*!
 * @typedef SessionType
 * @brief The type of session being used.
 * @constant ADAPT Session to modify or adjust the user enroll.
 * @constant ENROLL Session to register the user.
 * @constant VERIFY Session to authenticate the user.
 */
typedef NS_ENUM(NSInteger, SessionType) {
    
    ADAPT = 1,
    ENROLL,
    VERIFY
};

/*!
 * @typedef Language
 * @brief Language being used.
 * @constant ENGLISH Referring to english language.
 * @constant SPANISH Referring to spanish language.
 */
typedef NS_ENUM(NSInteger, Language) {
    
    ENGLISH = 1,
    SPANISH
};

/*!
 * @typedef FaceResponseStatus
 * @brief Face engine response status.
 * @constant FaceSessionCompletedWithSuccess Face session was completed successfully.
 * @constant FaceSessionFailed Face session was completed unsuccessfully.
 * @constant FaceAlreadyDetectedOnGallery This face couldn't be enrolled because it already exists on the gallery associated to another user.
 * @constant FaceAlreadyEnrolled This user already has his face enrolled.
 * @constant FaceNotEnrolled This user doesn't have a face enroll.
 * @constant NoFaceEngineConfigurationAvailable Face engine is not available for this client.
 * @constant FaceRequestLimitReached The face engine's number of requests have reached it's limit.
 * @constant FaceEngineProblemOcurred Some problem ocurred, check error for more information.
 */
typedef NS_ENUM(NSInteger, FaceResponseStatus) {
    
    FaceSessionCompletedWithSuccess = 1,
    FaceSessionFailed,
    FaceAlreadyDetectedOnGallery,
    FaceAlreadyEnrolled,
    FaceNotEnrolled,
    NoFaceEngineConfigurationAvailable,
    FaceRequestLimitReached,
    FaceEngineProblemOcurred
    
};

/*!
 * @typedef VoiceResponseStatus
 * @brief Voice engine response status.
 * @constant VoiceSessionCompletedWithSuccess Voice session was completed successfully.
 * @constant DialogueStartedWithSuccess Voice session started successfully.
 * @constant AudioSubmittedWithSuccess Voice audio was submitted successfully.
 * @constant VoiceSessionFailed Voice session was completed unsuccessfully.
 * @constant VoiceAlreadyEnrolled This user already has his voice enrolled.
 * @constant VoiceNotEnrolled This user doesn't have a voice enroll.
 * @constant NoVoiceEngineConfigurationAvailable Voice engine is not available for this client.
 * @constant VoiceRequestLimitReached The voice engine's number of request have reached it's limit.
 * @constant VoiceEngineProblemOcurred Some problem ocurred, check error for more information.
 */
typedef NS_ENUM(NSInteger, VoiceResponseStatus) {
    
    VoiceSessionCompletedWithSuccess = 1,
    DialogueStartedWithSuccess,
    AudioSubmittedWithSuccess,
    VoiceSessionFailed,
    VoiceAlreadyEnrolled,
    VoiceNotEnrolled,
    NoVoiceEngineConfigurationAvailable,
    VoiceRequestLimitReached,
    VoiceEngineProblemOcurred
    
};


#endif /* BiometridAuthEnums_h */
