//
//  BiometridAuthVoice.h
//  BiometridAuth
//
//  Created by Tiago Carvalho on 07/02/2018.
//  Copyright © 2018 Tiago Carvalho. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BiometridAuth.h"
#import "BiometridAuthVoiceResponse.h"

@interface BiometridAuthVoice : NSObject

+ (instancetype)sharedInstance;

/*!
 *  @discussion Voice engine.
 *  @param sessionType Session type.
 *  @param userId Biometrid's user identifier.
 *  @param language Biometrid's user language (ENGLISH / SPANISH).
 *  @param filePath File path of the audio file to be submitted (send nil to start a new dialogue and get a prompt).
 */
- (void)voiceEngine:(SessionType)sessionType user:(NSString*)userId withLanguage:(Language)language withFilePath:(NSString*)filePath andCallback:(void(^)(NSDictionary *response, BiometridAuthVoiceResponse* baVoiceResponse, NSError *error))completion;



@end

