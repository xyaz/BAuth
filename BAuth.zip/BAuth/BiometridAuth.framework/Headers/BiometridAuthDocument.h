//
//  BiometridAuthDocument.h
//  BiometridAuth
//
//  Created by Tiago Carvalho on 07/02/2018.
//  Copyright © 2018 Tiago Carvalho. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BiometridAuth.h"
#import "BiometridAuthFaceResponse.h"

@interface BiometridAuthDocument : NSObject

+ (instancetype)sharedInstance;

/*!
 *  @discussion Document engine, validate documents.
 *  @param frontImagePath Path of the file with the front image of the document.
 *  @param backImagePath Path of the file with the back image of the document.
 */
- (void)documentEngineValidateFrontImage:(NSString*)frontImagePath andBackImage:(NSString*)backImagePath andCallback:(void(^)(NSDictionary *response, BOOL wasProcessed, NSError *error))completion;

/*!
 *  @discussion Document engine, selfie compare.
 *  @param filePath1 File path of the first photo to be compared.
 *  @param filePath2 File path of the second photo to be compared.
 *  @param liveness Liveness result.
 */
- (void)documentEngineSelfieCompareWithFilePath:(NSString*)filePath1 andFilePath:(NSString*)filePath2 withLiveness:(BOOL)liveness andCallback:(void(^)(NSDictionary *response, BiometridAuthFaceResponse *baFaceResponse, NSError *error))completion;


@end
