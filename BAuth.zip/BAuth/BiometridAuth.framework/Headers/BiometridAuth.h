//
//  BiometridAuth.h
//  BiometridAuth
//
//  Created by Tiago Carvalho on 29/12/2017.
//  Copyright © 2017 Tiago Carvalho. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BiometridAuthSDK.h"
#import "BiometridAuthEnums.h"
#import "BiometridAuthHelper.h"
#import "BiometridAuthManager.h"
#import "BiometridAuthCamera.h"
#import "BiometridAuthVoice.h"
#import "BiometridAuthFace.h"
#import "BiometridAuthDocument.h"
#import "BiometridAuthEngine.h"
#import "BiometridAuthFaceResponse.h"
#import "BiometridAuthVoiceResponse.h"

//! Project version number for BiometridAuth.
FOUNDATION_EXPORT double BiometridAuthVersionNumber;

//! Project version string for BiometridAuth.
FOUNDATION_EXPORT const unsigned char BiometridAuthVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BiometridAuth/PublicHeader.h>


